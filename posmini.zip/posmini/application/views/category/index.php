<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>POS Mini</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">

    

    <!-- Bootstrap core CSS -->
<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>dashboard.css" rel="stylesheet">
  </head>
  <body>
    
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Administrator</a>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="navbar-nav">
    <div class="nav-item text-nowrap">
      <a class="nav-link px-3" href="<?= base_url('auth/logout') ?>">Sign out</a>
    </div>
  </div>
</header>

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo base_url('category'); ?>">
              <span data-feather="home"></span>
              Kategori
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('product'); ?>">
              <span data-feather="shopping-cart"></span>
              Produk
            </a>
          </li>
        </ul>
      </div>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <h2>Master Kategori Produk</h2>
      <button type="button" id="addCategory" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addFromCategory">
        Tambah Kategori
      </button>
      <div class="row"><h1></h1></div>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
          <tr>
              <td>No.</td>
              <td>Kategori</td>
              <td>Aksi</td>
            </tr>
          </thead>
          <tbody>
          <?php 
            $no=$this->uri->segment('3') + 1;
            foreach ($category as $row): 
          ?>
            <tr>
              <td><?php echo $no++; ?>.</td>
              <td><?php echo $row->category_name; ?></td>
              <td>
                <a href="<?php echo base_url('category/edit/'.$row->category_id); ?>" class="btn btn-success">Edit</a>
                <a data-delete-url="<?php echo base_url('category/delete/'.$row->category_id); ?>" onclick="deleteConfirm(this)" href="javascript:void(0);" class="btn btn-danger">Hapus</a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <nav aria-label="Page navigation">
          <ul class="pagination">
              <?php echo $this->pagination->create_links(); ?>
          </ul>
        </nav>
      </div>
    </main>
  </div>
</div>


    <script src="<?php echo base_url(); ?>js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      function deleteConfirm(event){
        Swal.fire({
          title: 'Konfirmasi!',
          text: 'Apa kamu yakin menghapus produk ini?',
          icon: 'warning',
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonText: 'Yes Delete',
          confirmButtonColor: 'red'
        }).then(dialog => {
          if(dialog.isConfirmed){
            window.location.assign(event.dataset.deleteUrl);
          }
        });
      }
    </script>
    
    <?php if($this->session->flashdata('success')): ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })

        Toast.fire({
          icon: 'success',
          title: '<?= $this->session->flashdata('success') ?>'
        })
      </script>
    <?php elseif($this->session->flashdata('failed')): ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })

        Toast.fire({
          icon: 'error',
          title: '<?= $this->session->flashdata('failed') ?>'
        })
      </script>
    <?php endif ?>
  </body>
</html>

<div class="modal" id="addFromCategory" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Kategori</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo base_url('category/add'); ?>" method="POST">
        <div class="modal-body">
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text">Kategori</span>
              </div>
              <input type="text" name="category_name" class="form-control" id="category">
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
          <button type="Submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>