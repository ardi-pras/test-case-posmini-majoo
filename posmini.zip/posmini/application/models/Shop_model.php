<?php

class Shop_model extends CI_Model {

    private $_table = "product";

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
}