<?php

class Auth_model extends CI_Model
{
    private $_table = "admin";
	const SESSION_KEY = 'username';

    public function rules()
	{
		return [
			[
				'field' => 'username',
				'label' => 'Username',
				'rules' => 'required'
			],
			[
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required|max_length[255]'
			]
		];
	}

    public function login($username, $password)
	{
		$user = $this->db->get_where($this->_table, ["username" => $username])->row();

		if (!$user) {
			return FALSE;
		}

		if (!password_verify($password, $user->password)) {
			return FALSE;
		}

		$this->session->set_userdata([self::SESSION_KEY => $user->username]);

		return $this->session->has_userdata(self::SESSION_KEY);
	}

    public function current_user()
	{
		if (!$this->session->has_userdata(self::SESSION_KEY)) {
			return null;
		}

		$username = $this->session->userdata(self::SESSION_KEY);
		$query = $this->db->get_where($this->_table, ['username' => $username]);
		return $query->row();
	}

	public function logout()
	{
		$this->session->unset_userdata(self::SESSION_KEY);
		return !$this->session->has_userdata(self::SESSION_KEY);
	}

}