<?php

class Product_model extends CI_Model
{

    private $_table = "product";

    public $product_id;
    public $product_name;
    public $product_category_id;
    public $product_description;
    public $product_price;
    public $product_image;

    public function rules(){
        return [
            ['field' => 'product_name',
            'label' => 'Nama Produk',
            'rules' => 'required'],

            ['field' => 'product_category_id',
            'label' => 'Kategori',
            'rules' => 'required'],

            ['field' => 'product_description',
            'label' => 'Deskripsi',
            'rules' => 'required'],

            ['field' => 'product_price',
            'label' => 'Harga',
            'rules' => 'required'],
        ];
    }

    public function getAll($limit,$offset)
    {
        $sql="SELECT * FROM product 
            INNER JOIN category ON category.category_id=product.product_category_id
            ORDER BY product.product_name ASC
            LIMIT ".$limit." OFFSET ".$offset."
        ";
        return $this->db->query($sql)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["product_id" => $id])->row();
    }

    public function save($file_name)
    {
        $post = $this->input->post();
        $this->product_name = $post["product_name"];
        $this->product_category_id = $post["product_category_id"];
        $this->product_description = $post["product_description"];
        $this->product_price = $post["product_price"];
        $this->product_image = $file_name;
        $is_exist = $this->db->get_where($this->_table, ["product_name" => $this->product_name])->row();
        if($is_exist)
        {
            return NULL;
        } else{
            return $this->db->insert($this->_table, $this);
        }
    }

    public function getCountAll(){
        return $this->db->get($this->_table)->num_rows();
    }
}