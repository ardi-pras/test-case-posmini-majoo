<?php

class Product extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array("auth_model", "product_model", "category_model"));
		if(!$this->auth_model->current_user()){
			redirect('auth/login');
		}
        $this->load->library(array('form_validation', 'pagination'));
    }

    public function index()
    {
        $config['base_url'] = base_url().'product/index/';
        $config['total_rows'] = $this->product_model->getCountAll();
        $config['per_page'] = 10;

        $this->pagination->initialize($config);
        $offset = !empty($this->uri->segment(3))?$this->uri->segment(3):0;

        $data["products"]=$this->product_model->getAll($config['per_page'], $offset);
        $this->load->view('product/index', $data);
    }

    public function add(){

        if($this->input->post())
        {
            $file_name = $this->input->post("product_name").uniqid(rand());
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['file_name'] = $file_name;
            $config['max_size'] = '100';
            $config['max_width'] = '1024';
            $config['max_height'] = '768';

            $this->load->library('upload', $config);

            if(!$this->upload->do_upload('product_image'))
            {
                $this->session->set_flashdata('failed', $this->upload->display_errors());
            } else{
                
                $upload_file = $this->upload->data();
                $filename=$upload_file['file_name'];

                $product = $this->product_model;
                $validation = $this->form_validation;
                $validation->set_rules($product->rules());

                if($validation->run())
                {
                    if($product->save($filename))
                    {
                        $this->session->set_flashdata('success', 'Produk berhasil dibuat!');
                    } else{
                        $this->session->set_flashdata('failed', 'Nama produk tidak boleh sama.');
                    }
                } else{
                    $this->session->set_flashdata('failed', 'Produk gagal dibuat!');
                }
            }
        }

        $data['category'] = $this->category_model->getAllCategory();

        $this->load->view('product/add', $data);
    }
}