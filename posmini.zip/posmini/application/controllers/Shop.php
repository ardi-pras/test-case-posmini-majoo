<?php

class Shop extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("shop_model");
    } 

    public function index()
    {
        $data['products'] = $this->shop_model->getAll();
        $this->load->view('shop', $data);
    }
}