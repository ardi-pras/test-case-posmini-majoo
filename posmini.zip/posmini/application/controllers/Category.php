<?php

class Category extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array("auth_model", "category_model"));
		if(!$this->auth_model->current_user()){
			redirect('auth/login');
		}
        $this->load->library(array('form_validation', 'pagination'));
    } 

    public function index()
	{
        $config['base_url'] = base_url().'category/index/';
        $config['total_rows'] = $this->category_model->getCountAll();
        $config['per_page'] = 10;

        $this->pagination->initialize($config);
        $offset = !empty($this->uri->segment(3))?$this->uri->segment(3):0;

        $data["category"]=$this->category_model->getAll($config['per_page'], $offset);
        $this->load->view('category/index', $data);
	}

    public function add(){

        $category = $this->category_model;
        $validation = $this->form_validation;
        $validation->set_rules($category->rules());

        if($validation->run())
        {
            $category->save();
            $this->session->set_flashdata('success', 'Kategori berhasil dibuat!');
        } else{
            $this->session->set_flashdata('failed', 'Kategori gagal dibuat!');
        }

        redirect('category');
    }

    public function edit($id=null)
    {
        if(!isset($id)) redirect('category');

        $category = $this->category_model;
        $validation = $this->form_validation;
        $validation->set_rules($category->rules());

        if($this->input->post())
        {
            if($validation->run())
            {
                $category->update();
                $this->session->set_flashdata('success', 'Kategori berhasil diubah!');
            } else{
                $this->session->set_flashdata('failed', 'Kategori gagal diubah!');
            }
        }

        $data["row"]=$category->getById($id);
        if(!$data["row"]) show_404();

        $this->load->view('category/edit', $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
            
        if ($this->category_model->delete($id)) {
            redirect('category');
        }
    }
}